input_data = {
    "search_data": "house",
    "currency": "$ (USD)",
    "price_min": 0,
    "price_max": 50,
    "menu_tab": 'Electronics'
}
