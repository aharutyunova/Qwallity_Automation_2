import pytest
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from TestData.config import URL


@pytest.fixture
def driver():
    driver = webdriver.Chrome(executable_path=ChromeDriverManager().install())
    driver.get(URL)
    driver.maximize_window()
    yield driver
    driver.quit()
